package com.biren.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    final int GREEN=Color.rgb(8,127,91), TEXT=Color.rgb(21,33,29), MUTED=Color.rgb(113,128,122);
    final int BG=Color.rgb(246,248,247), CARD=Color.WHITE, RED=Color.rgb(198,40,40), LINE=Color.rgb(227,233,230);
    LinearLayout root, content, nav;
    SharedPreferences sp;
    String month;
    final String[] defaultNames={"Food & Dining","Shopping","Transport","Bills & Utilities","Health","Education","Entertainment","Travel","Savings","Family","Others"};
    String[] names;
    double[] pct;
    String[] accountNames={"Main Account","Savings","Wallet","Bills","Investment"};
    double[] opening=new double[5], balance=new double[5];
    JSONArray txs;
    NumberFormat nf=NumberFormat.getCurrencyInstance(new Locale("en","IN"));
    {
        nf.setMinimumFractionDigits(0);
        nf.setMaximumFractionDigits(0);
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        sp=getSharedPreferences("biren_new",MODE_PRIVATE);
        load();
        showSplash();
    }
    String money(double v){ return nf.format(v); }
    String key(String m){ return m.replace(" ","_"); }
    void load(){
        month=new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date());
        names=new String[11]; pct=new double[11];
        for(int i=0;i<11;i++){ names[i]=sp.getString("cat_name_"+i,defaultNames[i]); pct[i]=sp.getFloat("cat_pct_"+i,9.090909f); }
        for(int i=0;i<5;i++){ accountNames[i]=sp.getString("acc_name_"+i,accountNames[i]); opening[i]=sp.getFloat("acc_open_"+i,0); }
        try{txs=new JSONArray(sp.getString("txs","[]"));}catch(Exception e){txs=new JSONArray();}
        recalcBalances();
    }
    void persist(){
        SharedPreferences.Editor e=sp.edit();
        for(int i=0;i<11;i++){e.putString("cat_name_"+i,names[i]);e.putFloat("cat_pct_"+i,(float)pct[i]);}
        for(int i=0;i<5;i++){e.putString("acc_name_"+i,accountNames[i]);e.putFloat("acc_open_"+i,(float)opening[i]);}
        e.putString("txs",txs.toString()).apply();
    }
    void recalcBalances(){
        for(int i=0;i<5;i++) balance[i]=opening[i];
        for(int i=0;i<txs.length();i++) try{
            JSONObject o=txs.getJSONObject(i);
            String type=o.optString("type"); double a=o.optDouble("amount");
            if(type.equals("Income")) balance[o.optInt("account")]+=a;
            else if(type.equals("Expense")) balance[o.optInt("account")]-=a;
            else if(type.equals("Transfer")){
                balance[o.optInt("from")]-=a; balance[o.optInt("to")]+=a;
            }
        }catch(Exception ignored){}
    }
    void showSplash(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER); root.setBackgroundColor(BG);
        ImageView icon=new ImageView(this); icon.setImageResource(com.biren.app.R.drawable.biren_logo);
        root.addView(icon,new LinearLayout.LayoutParams(96,96));
        TextView brand=t("BiReN",40,TEXT); brand.setTypeface(Typeface.DEFAULT,Typeface.BOLD); brand.setGravity(Gravity.CENTER);
        root.addView(brand);
        TextView tag=t("Plan Money. Grow Wealth.",16,MUTED); tag.setGravity(Gravity.CENTER); root.addView(tag);
        setContentView(root);
        new Handler().postDelayed(()->home(),650);
    }
    TextView t(String s,float z,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);return v;}
    GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(r);return g;}
    TextView button(String s){TextView v=t(s,15,GREEN);v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setGravity(Gravity.CENTER);v.setPadding(18,14,18,14);v.setBackground(bg(Color.WHITE,28));return v;}
    TextView navItem(String s,String emoji,boolean selected){
        TextView v=t(emoji+"\n"+s,12,selected?GREEN:MUTED);v.setGravity(Gravity.CENTER);v.setTypeface(Typeface.DEFAULT,selected?Typeface.BOLD:Typeface.NORMAL);
        v.setPadding(4,8,4,7);v.setLayoutParams(new LinearLayout.LayoutParams(0,72,1));return v;
    }
    void base(String title){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        ScrollView sv=new ScrollView(this); content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(22,18,22,24);sv.addView(content);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        nav=new LinearLayout(this);nav.setBackgroundColor(Color.WHITE);nav.setElevation(10);root.addView(nav,new LinearLayout.LayoutParams(-1,72));
        String[] ns={"Home","Accounts","Add","Reports","More"}, es={"⌂","▣","+","▤","•••"};
        for(int i=0;i<5;i++){final int x=i;TextView n=navItem(ns[i],es[i],title.equals(ns[i]));n.setOnClickListener(v->{if(x==0)home();if(x==1)accounts();if(x==2)add();if(x==3)reports();if(x==4)more();});nav.addView(n);}
        setContentView(root);
    }
    TextView heading(String s){TextView v=t(s,30,TEXT);v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setPadding(0,0,0,5);return v;}
    TextView sub(String s){return t(s,15,MUTED);}
    LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(18,17,18,17);c.setBackground(bg(CARD,28));c.setElevation(2);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,10,0,0);c.setLayoutParams(p);return c;}
    TextView label(String s){TextView v=t(s,13,MUTED);v.setAllCaps(true);return v;}
    void addTitle(String title,String subtitle){content.addView(heading(title));if(subtitle!=null)content.addView(sub(subtitle));}
    double incomeFor(String m){double x=0;for(int i=0;i<txs.length();i++)try{JSONObject o=txs.getJSONObject(i);if(o.optString("month").equals(m)&&o.optString("type").equals("Income"))x+=o.optDouble("amount");}catch(Exception e){}return x;}
    double expenseFor(String m){double x=0;for(int i=0;i<txs.length();i++)try{JSONObject o=txs.getJSONObject(i);if(o.optString("month").equals(m)&&o.optString("type").equals("Expense"))x+=o.optDouble("amount");}catch(Exception e){}return x;}
    double openingTotal(){double x=0;for(double v:opening)x+=v;return x;}
    double currentTotal(){double x=0;for(double v:balance)x+=v;return x;}
    double monthBudget(String m){return incomeFor(m);}
    double catSpent(String m,int c){double x=0;for(int i=0;i<txs.length();i++)try{JSONObject o=txs.getJSONObject(i);if(o.optString("month").equals(m)&&o.optString("type").equals("Expense")&&o.optInt("cat",-1)==c)x+=o.optDouble("amount");}catch(Exception e){}return x;}
    double carryFor(String m,int c){
        Calendar cal=Calendar.getInstance(); try{cal.setTime(new SimpleDateFormat("yyyy-MM",Locale.US).parse(m));}catch(Exception e){return 0;}
        cal.add(Calendar.MONTH,-1);String prev=new SimpleDateFormat("yyyy-MM",Locale.US).format(cal.getTime());
        double prevIncome=incomeFor(prev), prevBudget=prevIncome*pct[c]/100.0, prevSpent=catSpent(prev,c);
        return Math.max(0,prevBudget-prevSpent);
    }
    void home(){
        load();base("Home");
        Calendar cal=Calendar.getInstance();try{cal.setTime(new SimpleDateFormat("yyyy-MM",Locale.US).parse(month));}catch(Exception ignored){}String nice=new SimpleDateFormat("MMMM yyyy",Locale.US).format(cal.getTime());
        addTitle("Good morning!","Your money, clearly organized.");
        LinearLayout hero=card();hero.setBackground(bg(GREEN,30));
        TextView a=label("CURRENT BALANCE");a.setTextColor(Color.WHITE);hero.addView(a);
        TextView bal=t(money(currentTotal()),38,Color.WHITE);bal.setTypeface(Typeface.DEFAULT,Typeface.BOLD);hero.addView(bal);
        TextView hx=t("Opening "+money(openingTotal())+"  •  "+nice,15,Color.WHITE);hero.addView(hx);
        content.addView(hero);
        TextView mon=t("‹   "+nice+"   ›",18,Color.WHITE);mon.setGravity(Gravity.CENTER);mon.setPadding(15,17,15,17);mon.setBackground(bg(GREEN,26));mon.setOnClickListener(v->monthPicker());LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,-2);mp.setMargins(0,12,0,4);content.addView(mon,mp);
        double inc=incomeFor(month), spent=expenseFor(month), rem=inc-spent, close=openingTotal()+inc-spent;
        LinearLayout stats=new LinearLayout(this);stats.setOrientation(LinearLayout.HORIZONTAL);
        String[] ss={"Monthly Income","Monthly Spent","Monthly Remaining"};double[] vv={inc,spent,rem};
        for(int i=0;i<3;i++){LinearLayout c=card();c.setPadding(14,15,14,15);c.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1));if(i>0)((LinearLayout.LayoutParams)c.getLayoutParams()).setMargins(8,10,0,0);c.addView(sub(ss[i]));TextView z=t(money(vv[i]),19,TEXT);z.setTypeface(Typeface.DEFAULT,Typeface.BOLD);c.addView(z);stats.addView(c);}
        content.addView(stats);
        TextView closeL=t("Closing balance: "+money(close),14,MUTED);closeL.setPadding(4,12,4,0);content.addView(closeL);
        TextView ah=t("Accounts",24,TEXT);ah.setTypeface(Typeface.DEFAULT,Typeface.BOLD);ah.setPadding(0,18,0,0);content.addView(ah);
        content.addView(sub("5 accounts"));
        for(int i=0;i<5;i++) addAccountCard(i,false);
        TextView bh=t("Budget at a glance",24,TEXT);bh.setTypeface(Typeface.DEFAULT,Typeface.BOLD);bh.setPadding(0,20,0,4);content.addView(bh);
        double budget=monthBudget(month);for(int i=0;i<11;i++) addBudgetMini(i,budget);
        addRecentTransactions(5);
    }
    void addAccountCard(int i,boolean detail){
        LinearLayout c=card();TextView n=t(accountNames[i],19,TEXT);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);c.addView(n);
        c.addView(sub("Current balance"));TextView b=t(money(balance[i]),27,GREEN);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);c.addView(b);
        c.addView(sub("Opening "+money(opening[i])));
        TextView meta=t("Tap to view account",14,MUTED);meta.setPadding(0,8,0,0);c.addView(meta);
        if(!detail)c.setOnClickListener(v->accountDetail(i));
        content.addView(c);
    }
    void addBudgetMini(int i,double income){
        double budget=income*pct[i]/100.0+carryFor(month,i), spent=catSpent(month,i), rem=Math.max(0,budget-spent);
        LinearLayout c=card();LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
        TextView n=t(names[i],16,TEXT);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);row.addView(n,new LinearLayout.LayoutParams(0,-2,1));
        TextView p=t(String.format(Locale.US,"%.2f%%",pct[i]),13,GREEN);row.addView(p);c.addView(row);
        c.addView(sub("Budget "+money(budget)+"   •   Spent "+money(spent)+"   •   Remaining "+money(rem)));
        if(spent>budget){TextView ov=t("Overspent "+money(spent-budget),14,RED);ov.setTypeface(Typeface.DEFAULT,Typeface.BOLD);c.addView(ov);}
        content.addView(c);
    }
    void accounts(){
        load();base("Accounts");addTitle("Accounts","Five accounts with opening and current balances.");
        for(int i=0;i<5;i++)addAccountCard(i,false);
        TextView info=t("Current Balance = all opening balances + income − expenses. Transfers move money between accounts and do not change total balance.",13,MUTED);info.setPadding(4,18,4,10);content.addView(info);
    }
    void accountDetail(int idx){
        load();base("Accounts");addTitle(accountNames[idx],"Current balance and transaction history.");
        LinearLayout hero=card();hero.addView(label("CURRENT BALANCE"));TextView b=t(money(balance[idx]),34,GREEN);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);hero.addView(b);hero.addView(sub("Opening balance "+money(opening[idx])));content.addView(hero);
        TextView edit=button("EDIT ACCOUNT");edit.setOnClickListener(v->editAccount(idx));content.addView(edit);
        TextView h=t("Transactions",22,TEXT);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);h.setPadding(0,18,0,2);content.addView(h);
        int shown=0;
        for(int i=txs.length()-1;i>=0;i--)try{JSONObject o=txs.getJSONObject(i);boolean hit=(o.optInt("account",-1)==idx||o.optInt("from",-1)==idx||o.optInt("to",-1)==idx);if(!hit)continue;shown++;final int txIndex=i;LinearLayout c=card();String type=o.optString("type");double a=o.optDouble("amount");c.addView(t(type,16,TEXT));c.addView(t((type.equals("Expense")?"-":type.equals("Income")?"+":"↔ ")+money(a),20,type.equals("Expense")?RED:GREEN));c.addView(sub(o.optString("date")+"  •  "+o.optString("note","")));TextView manage=t("EDIT   •   DELETE",13,GREEN);manage.setTypeface(Typeface.DEFAULT,Typeface.BOLD);manage.setPadding(0,12,0,0);manage.setOnClickListener(v->transactionActions(txIndex));c.addView(manage);c.setOnClickListener(v->transactionActions(txIndex));content.addView(c);}catch(Exception e){}
        if(shown==0){LinearLayout c=card();c.addView(t("No transactions yet",17,TEXT));c.addView(t("₹0",22,TEXT));c.addView(sub("Add your first income or expense."));content.addView(c);}
    }
    void add(){
        load();base("Add");addTitle("Add transaction","Record income, expense, or transfer.");
        Spinner type=new Spinner(this);type.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Expense","Income","Transfer"}));content.addView(type);
        EditText amount=field("Amount");amount.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED);content.addView(amount);addCalculatorKeys(amount);
        Calendar transactionDate=defaultTransactionDate();
        TextView dateButton=button("TRANSACTION DATE  •  "+formatDate(transactionDate.getTime()));
        dateButton.setTextColor(TEXT);dateButton.setGravity(Gravity.CENTER_VERTICAL);dateButton.setBackground(bg(Color.WHITE,18));
        dateButton.setOnClickListener(v->pickTransactionDate(dateButton,transactionDate));
        content.addView(dateButton);
        Spinner acc=new Spinner(this);String[] aa=accountNames.clone();acc.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,aa));content.addView(acc);
        Spinner cat=new Spinner(this);cat.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));content.addView(cat);
        Spinner to=new Spinner(this);to.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,aa));TextView toL=label("TO ACCOUNT (TRANSFER ONLY)");content.addView(toL);content.addView(to);
        EditText note=field("Optional note");note.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);content.addView(note);
        TextView save=button("SAVE TRANSACTION");save.setTextColor(Color.WHITE);save.setBackground(bg(GREEN,28));save.setOnClickListener(v->{
            String s=amount.getText().toString().trim();if(s.isEmpty()){toast("Enter an amount");return;}double val=Double.parseDouble(s);if(val<=0){toast("Amount must be positive");return;}
            int ai=acc.getSelectedItemPosition();int ci=cat.getSelectedItemPosition();String typ=(String)type.getSelectedItem();
            try{
                JSONObject o=new JSONObject();o.put("type",typ);o.put("amount",val);o.put("account",ai);o.put("cat",ci);o.put("date",formatDate(transactionDate.getTime()));o.put("month",monthFromDate(transactionDate.getTime()));o.put("note",note.getText().toString());
                if(typ.equals("Transfer")){int ti=to.getSelectedItemPosition();if(ti==ai){toast("Choose different accounts");return;}o.put("from",ai);o.put("to",ti);}
                txs.put(o);persist();recalcBalances();toast("Saved successfully");home();
            }catch(Exception e){toast("Something went wrong. Please check the information and try again.");}
        });content.addView(save);
    }
    EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(17);e.setSingleLine(true);e.setPadding(14,10,14,10);e.setBackground(bg(Color.WHITE,18));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,9,0,0);e.setLayoutParams(p);return e;}
    void addCalculatorKeys(final EditText amount){
        LinearLayout keys=new LinearLayout(this);
        keys.setOrientation(LinearLayout.HORIZONTAL);
        keys.setGravity(Gravity.CENTER);
        keys.setPadding(0,4,0,2);

        final String[] ops={"+","−","×","÷","="};
        for(final String op:ops){
            Button b=new Button(this);
            b.setText(op);
            b.setTextSize(20);
            b.setTextColor(GREEN);
            b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
            b.setAllCaps(false);
            b.setGravity(Gravity.CENTER);
            b.setMinHeight(0);
            b.setMinimumHeight(0);
            b.setMinWidth(0);
            b.setMinimumWidth(0);
            b.setPadding(0,0,0,0);
            b.setBackground(bg(Color.WHITE,18));

            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,58,1);
            lp.setMargins(3,3,3,3);
            keys.addView(b,lp);

            b.setOnClickListener(v -> applyCalculatorButton(amount,op));
        }

        content.addView(keys);

        TextView hint=sub("Calculator: type 1000+250-50 or tap + − × ÷, then =.");
        hint.setPadding(4,0,4,4);
        content.addView(hint);
    }

    void applyCalculatorButton(EditText amount,String op){
        amount.requestFocus();

        String current=amount.getText().toString().trim();

        if(op.equals("=")){
            if(current.isEmpty()){
                toast("Enter a number first");
                return;
            }
            try{
                double result=evalAmount(current);
                amount.setText(trimNumber(result));
                amount.setSelection(amount.length());
            }catch(Exception e){
                toast("Invalid calculation. Try 1000+250-50");
            }
            return;
        }

        String x;
        if(op.equals("−")) x="-";
        else if(op.equals("×")) x="*";
        else if(op.equals("÷")) x="/";
        else x="+";

        if(current.isEmpty()){
            if(x.equals("-")){
                amount.setText("-");
                amount.setSelection(amount.length());
            }else{
                toast("Enter a number first");
            }
            return;
        }

        char last=current.charAt(current.length()-1);
        if(last=='+' || last=='-' || last=='*' || last=='/'){
            amount.getText().replace(current.length()-1,current.length(),x);
        }else{
            amount.getText().insert(amount.length(),x);
        }

        amount.setSelection(amount.length());
    }

    String trimNumber(double v){if(Math.abs(v-Math.rint(v))<0.0000001)return String.valueOf((long)Math.rint(v));return String.valueOf(v);}
    double evalAmount(String expr){
        if(expr==null)throw new IllegalArgumentException();String x=expr.replace("₹","").replace(",","").replace(" ","").replace("−","-").replace("×","*").replace("÷","/");if(x.isEmpty())throw new IllegalArgumentException();
        final String f=x;final int[] p={0};
        class Parser{double expression(){double v=term();while(p[0]<f.length()){char c=f.charAt(p[0]);if(c!='+'&&c!='-')break;p[0]++;double r=term();v=c=='+'?v+r:v-r;}return v;}double term(){double v=factor();while(p[0]<f.length()){char c=f.charAt(p[0]);if(c!='*'&&c!='/')break;p[0]++;double r=factor();if(c=='/'&&Math.abs(r)<1e-12)throw new IllegalArgumentException();v=c=='*'?v*r:v/r;}return v;}double factor(){if(p[0]<f.length()&&f.charAt(p[0])=='-'){p[0]++;return -factor();}if(p[0]<f.length()&&f.charAt(p[0])=='+'){p[0]++;return factor();}if(p[0]<f.length()&&f.charAt(p[0])=='('){p[0]++;double v=expression();if(p[0]>=f.length()||f.charAt(p[0])!=')')throw new IllegalArgumentException();p[0]++;return v;}int st=p[0];while(p[0]<f.length()&&(Character.isDigit(f.charAt(p[0]))||f.charAt(p[0])=='.'))p[0]++;if(st==p[0])throw new IllegalArgumentException();return Double.parseDouble(f.substring(st,p[0]));}}
        double v=new Parser().expression();if(p[0]!=f.length()||Double.isNaN(v)||Double.isInfinite(v)||v<0)throw new IllegalArgumentException();return v;
    }
    void transactionActions(int index){
        if(index<0||index>=txs.length())return;try{JSONObject o=txs.getJSONObject(index);String[] items={"Edit transaction","Delete transaction"};new AlertDialog.Builder(this).setTitle(o.optString("type")+" • "+money(o.optDouble("amount"))).setItems(items,(d,w)->{if(w==0)editTransaction(index);else deleteTransaction(index);}).show();}catch(Exception e){toast("Unable to open transaction");}
    }
    void deleteTransaction(int index){
        new AlertDialog.Builder(this).setTitle("Delete transaction?").setMessage("This transaction will be removed and all balances will be recalculated.").setNegativeButton("CANCEL",null).setPositiveButton("DELETE",(d,w)->{txs.remove(index);persist();recalcBalances();toast("Transaction deleted");home();}).show();
    }
    void editTransaction(int index){
        try{
            JSONObject o=txs.getJSONObject(index);String oldType=o.optString("type","Expense");
            LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(8,0,8,0);
            Spinner type=new Spinner(this);type.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Expense","Income","Transfer"}));type.setSelection(oldType.equals("Income")?1:oldType.equals("Transfer")?2:0);box.addView(type);
            EditText amount=field("Amount");amount.setText(trimNumber(o.optDouble("amount")));amount.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED);box.addView(amount);
            Calendar transactionDate=parseTransactionDate(o.optString("date",""),month);
            TextView dateButton=button("TRANSACTION DATE  •  "+formatDate(transactionDate.getTime()));
            dateButton.setTextColor(TEXT);dateButton.setGravity(Gravity.CENTER_VERTICAL);dateButton.setBackground(bg(Color.WHITE,18));
            dateButton.setOnClickListener(v->pickTransactionDate(dateButton,transactionDate));
            box.addView(dateButton);
            Spinner acc=new Spinner(this);acc.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,accountNames));int oldAcc=o.optInt("account",0);acc.setSelection(Math.max(0,Math.min(4,oldAcc)));box.addView(acc);
            Spinner cat=new Spinner(this);cat.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));cat.setSelection(Math.max(0,Math.min(10,o.optInt("cat",0))));box.addView(cat);
            Spinner to=new Spinner(this);to.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,accountNames));to.setSelection(Math.max(0,Math.min(4,o.optInt("to",0))));box.addView(to);
            EditText note=field("Optional note");note.setText(o.optString("note",""));note.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);box.addView(note);
            AlertDialog d=new AlertDialog.Builder(this).setTitle("Edit transaction").setView(box).setNegativeButton("CANCEL",null).setPositiveButton("SAVE",null).create();
            d.setOnShowListener(q->{d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{double val=evalAmount(amount.getText().toString());String typ=(String)type.getSelectedItem();int ai=acc.getSelectedItemPosition();int ci=cat.getSelectedItemPosition();o.put("type",typ);o.put("amount",val);o.put("account",ai);o.put("cat",ci);o.put("date",formatDate(transactionDate.getTime()));o.put("month",monthFromDate(transactionDate.getTime()));o.put("note",note.getText().toString());if(typ.equals("Transfer")){int ti=to.getSelectedItemPosition();if(ti==ai){toast("Choose different accounts");return;}o.put("from",ai);o.put("to",ti);}else{o.remove("from");o.remove("to");}persist();recalcBalances();toast("Transaction updated");d.dismiss();accountDetail(ai);}catch(Exception e){toast("Enter a valid amount or calculation");}});});d.getWindow();d.show();
        }catch(Exception e){toast("Unable to edit transaction");}
    }

    void editAccount(int idx){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(10,0,10,0);
        EditText n=field("Account name");n.setText(accountNames[idx]);n.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);box.addView(n);
        EditText op=field("Opening balance");op.setText(String.valueOf(opening[idx]));op.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);box.addView(op);
        AlertDialog d=new AlertDialog.Builder(this).setTitle("Edit account").setView(box).setNegativeButton("CANCEL",null).setPositiveButton("SAVE",(x,w)->{
            accountNames[idx]=n.getText().toString().trim().isEmpty()?accountNames[idx]:n.getText().toString().trim();try{opening[idx]=Double.parseDouble(op.getText().toString());}catch(Exception ignored){}
            persist();recalcBalances();accountDetail(idx);
        }).create();d.show();n.requestFocus();d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
    }
    void budget(){
        load();base("Budget");addTitle("Monthly Budget","Budget vs spend vs remaining for every category.");
        TextView edit=button("EDIT CATEGORIES & ALLOCATION");edit.setTextColor(Color.WHITE);edit.setBackground(bg(GREEN,28));edit.setOnClickListener(v->editCategories());content.addView(edit);
        double income=incomeFor(month);LinearLayout top=card();top.addView(label("MONTHLY BUDGET"));TextView x=t(money(income),32,GREEN);x.setTypeface(Typeface.DEFAULT,Typeface.BOLD);top.addView(x);top.addView(sub("Based on this month's income and saved allocation."));content.addView(top);
        for(int i=0;i<11;i++)categoryCard(i,income);
    }
    void categoryCard(int i,double income){
        double budget=income*pct[i]/100.0+carryFor(month,i),spent=catSpent(month,i),remaining=Math.max(0,budget-spent),over=Math.max(0,spent-budget);
        LinearLayout c=card();LinearLayout r=new LinearLayout(this);TextView n=t(names[i],17,TEXT);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);r.addView(n,new LinearLayout.LayoutParams(0,-2,1));r.addView(t(String.format(Locale.US,"%.2f%%",pct[i]),14,GREEN));c.addView(r);
        c.addView(sub("Budget                 Spent                 Remaining"));
        TextView vals=t(money(budget)+"     "+money(spent)+"     "+money(remaining),16,TEXT);vals.setTypeface(Typeface.DEFAULT,Typeface.BOLD);c.addView(vals);
        if(over>0){TextView ov=t("● Overspent "+money(over),14,RED);ov.setPadding(0,7,0,0);c.setBackground(bg(Color.rgb(253,236,236),28));c.addView(ov);}
        else {ProgressBar pb=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);pb.setMax(100);pb.setProgress(budget<=0?0:(int)Math.min(100,spent/budget*100));c.addView(pb);}
        content.addView(c);
    }
    void editCategories(){
        load();base("Budget");addTitle("Edit categories & allocation","Change names and percentages. Total must equal 100%.");
        EditText[] ns=new EditText[11];EditText[] ps=new EditText[11];LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);
        for(int i=0;i<11;i++){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView l=t(String.valueOf((char)('A'+i)),15,GREEN);l.setTypeface(Typeface.DEFAULT,Typeface.BOLD);row.addView(l,new LinearLayout.LayoutParams(30,-2));ns[i]=field(names[i]);ns[i].setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);ps[i]=field(String.valueOf(pct[i]));ps[i].setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);row.addView(ns[i],new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(95,-2);pp.setMargins(8,0,0,0);row.addView(ps[i],pp);form.addView(row);}
        content.addView(form);
        TextView total=t("TOTAL ALLOCATION: 100%",16,GREEN);total.setTypeface(Typeface.DEFAULT,Typeface.BOLD);total.setPadding(4,14,4,8);content.addView(total);
        TextView save=button("SAVE CHANGES");save.setTextColor(Color.WHITE);save.setBackground(bg(GREEN,28));save.setOnClickListener(v->{double sum=0;try{for(int i=0;i<11;i++)sum+=Double.parseDouble(ps[i].getText().toString());}catch(Exception e){toast("Enter valid percentages");return;}if(Math.abs(sum-100)>0.01){toast("Allocation must equal 100%");return;}for(int i=0;i<11;i++){names[i]=ns[i].getText().toString().trim().isEmpty()?names[i]:ns[i].getText().toString().trim();pct[i]=Double.parseDouble(ps[i].getText().toString());}persist();toast("Saved successfully");budget();});content.addView(save);
    }
    void reports(){
        load();base("Reports");addTitle("Reports","Professional monthly financial overview.");
        double inc=incomeFor(month),spent=expenseFor(month),remaining=inc-spent;
        summaryCard("Monthly Overview","Income",inc,"Spent",spent,"Remaining",remaining);
        addTransactionHistory(0);
        TextView h=t("Budget Performance",23,TEXT);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);h.setPadding(0,18,0,2);content.addView(h);
        for(int i=0;i<11;i++){double b=inc*pct[i]/100.0+carryFor(month,i),s=catSpent(month,i),r=Math.max(0,b-s),o=Math.max(0,s-b);LinearLayout c=card();c.addView(t(names[i],16,TEXT));c.addView(sub("Budget "+money(b)+"  •  Spent "+money(s)+"  •  Remaining "+money(r)));if(o>0){TextView ov=t("Overspent "+money(o),14,RED);ov.setTypeface(Typeface.DEFAULT,Typeface.BOLD);c.addView(ov);}content.addView(c);}
        TextView ah=t("Account Performance",23,TEXT);ah.setTypeface(Typeface.DEFAULT,Typeface.BOLD);ah.setPadding(0,18,0,2);content.addView(ah);for(int i=0;i<5;i++)addAccountCard(i,true);
    }
    void addRecentTransactions(int limit){
        TextView h=t("Recent Transactions",23,TEXT);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);h.setPadding(0,18,0,2);content.addView(h);
        int shown=0;for(int i=txs.length()-1;i>=0&&shown<limit;i--){try{JSONObject o=txs.getJSONObject(i);addTransactionCard(o,i);shown++;}catch(Exception ignored){}}
        if(shown==0)content.addView(sub("No transactions yet."));
        TextView all=button("VIEW FULL TRANSACTION HISTORY");all.setTextColor(Color.WHITE);all.setBackground(bg(GREEN,28));all.setOnClickListener(v->reports());content.addView(all);
    }
    void addTransactionHistory(int ignored){
        TextView h=t("Transaction History",23,TEXT);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);h.setPadding(0,18,0,2);content.addView(h);
        if(txs.length()==0){content.addView(sub("No transactions recorded yet."));return;}
        for(int i=txs.length()-1;i>=0;i--){try{JSONObject o=txs.getJSONObject(i);addTransactionCard(o,i);}catch(Exception ignored2){}}
    }
    void addTransactionCard(JSONObject o,int index){
        LinearLayout c=card();String type=o.optString("type","Expense");double a=o.optDouble("amount");int ai=o.optInt("account",0);String account=(ai>=0&&ai<accountNames.length)?accountNames[ai]:"Account";
        c.addView(t(type,16,TEXT));c.addView(t((type.equals("Expense")?"-":type.equals("Income")?"+":"↔ ")+money(a),20,type.equals("Expense")?RED:GREEN));
        String detail=o.optString("date","")+"  •  "+account; if(type.equals("Transfer")){int ti=o.optInt("to",-1);if(ti>=0&&ti<accountNames.length)detail+=" → "+accountNames[ti];}c.addView(sub(detail));String note=o.optString("note","");if(!note.isEmpty())c.addView(sub(note));
        TextView manage=t("EDIT   •   DELETE",13,GREEN);manage.setTypeface(Typeface.DEFAULT,Typeface.BOLD);manage.setPadding(0,12,0,0);manage.setOnClickListener(v->transactionActions(index));c.addView(manage);c.setOnClickListener(v->transactionActions(index));content.addView(c);
    }
    void summaryCard(String title,String a,double av,String b,double bv,String c,double cv){
        LinearLayout box=card();box.addView(t(title,18,TEXT));LinearLayout r=new LinearLayout(this);
        String[] ls={a,b,c};double[] vs={av,bv,cv};for(int i=0;i<3;i++){LinearLayout q=new LinearLayout(this);q.setOrientation(LinearLayout.VERTICAL);q.setPadding(4,10,4,4);q.addView(sub(ls[i]));TextView z=t(money(vs[i]),18,i==1?RED:GREEN);z.setTypeface(Typeface.DEFAULT,Typeface.BOLD);q.addView(z);r.addView(q,new LinearLayout.LayoutParams(0,-2,1));}box.addView(r);content.addView(box);
    }
    void more(){
        load();base("More");addTitle("More","Settings and app controls.");
        TextView b=button("BUDGET & CATEGORIES");b.setOnClickListener(v->budget());content.addView(b);
        TextView d=button("DARK MODE");d.setOnClickListener(v->toast("Use system dark mode for the premium dark theme."));content.addView(d);
        TextView about=button("ABOUT BIREN");about.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("BiReN").setMessage("Plan Money. Grow Wealth.\\n\\nA premium personal finance planner.").setPositiveButton("OK",null).show());content.addView(about);
    }
    void monthPicker(){
        String[] months=new String[13];Calendar c=Calendar.getInstance();for(int i=0;i<13;i++){c.setTime(new Date());c.add(Calendar.MONTH,i-6);months[i]=new SimpleDateFormat("MMMM yyyy",Locale.US).format(c.getTime());}
        new AlertDialog.Builder(this).setTitle("Select month").setItems(months,(d,w)->{Calendar c2=Calendar.getInstance();c2.add(Calendar.MONTH,w-6);month=new SimpleDateFormat("yyyy-MM",Locale.US).format(c2.getTime());home();}).show();
    }
    String formatDate(Date d){return new SimpleDateFormat("dd MMM yyyy",Locale.US).format(d);}
    String monthFromDate(Date d){return new SimpleDateFormat("yyyy-MM",Locale.US).format(d);}
    Calendar defaultTransactionDate(){
        Calendar c=Calendar.getInstance();
        try{
            Date selected=new SimpleDateFormat("yyyy-MM",Locale.US).parse(month);
            Calendar m=Calendar.getInstance();m.setTime(selected);
            if(m.get(Calendar.YEAR)!=c.get(Calendar.YEAR)||m.get(Calendar.MONTH)!=c.get(Calendar.MONTH)){
                c=m;c.set(Calendar.DAY_OF_MONTH,1);
            }
        }catch(Exception e){}
        return c;
    }
    Calendar parseTransactionDate(String value,String fallbackMonth){
        Calendar c=Calendar.getInstance();
        try{
            Date d=new SimpleDateFormat("dd MMM yyyy",Locale.US).parse(value);
            c.setTime(d);return c;
        }catch(Exception e){}
        try{
            Date d=new SimpleDateFormat("yyyy-MM",Locale.US).parse(fallbackMonth);
            c.setTime(d);c.set(Calendar.DAY_OF_MONTH,1);
        }catch(Exception e){}
        return c;
    }
    void pickTransactionDate(TextView target,Calendar selected){
        DatePickerDialog dp=new DatePickerDialog(this,(view,year,monthOfYear,dayOfMonth)->{
            selected.set(Calendar.YEAR,year);selected.set(Calendar.MONTH,monthOfYear);selected.set(Calendar.DAY_OF_MONTH,dayOfMonth);
            target.setText("TRANSACTION DATE  •  "+formatDate(selected.getTime()));
        },selected.get(Calendar.YEAR),selected.get(Calendar.MONTH),selected.get(Calendar.DAY_OF_MONTH));
        dp.show();
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
