# BiReN — Plan Money. Grow Wealth.

## New-start Android project

This project is intentionally built from a clean project structure rather than copying the previous BiReN application.

### Core model
- 5 accounts with editable names and opening balances.
- Current balance = sum of all account balances, including opening balances.
- Monthly remaining = monthly income - monthly expense, never displayed as a negative value.
- Closing balance = opening balance + monthly income - monthly expense.
- Transfers move money between accounts and do not change total current balance.
- 11 editable budget categories.
- Editable allocation percentages; total must equal 100%.
- Monthly category budget = monthly income × allocation % + unused prior-month category budget.
- Budget vs spent vs remaining shown for every category.
- Overspending highlighted in red.
- Monthly navigation and persistent local data.

## Branding
BiReN
Plan Money. Grow Wealth.

## Build
Android Studio with JDK 17, or GitHub Actions using Gradle 8.10.2.
